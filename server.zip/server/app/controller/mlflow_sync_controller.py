import mlflow
import os

from pydantic import BaseModel

class SyncModelsRequest(BaseModel):
    models: dict    

class MLFlowSyncController:
    def __init__(self):
        self._set_mlflow_tracking_uri()
        self.mlflow_client = mlflow.tracking.MlflowClient()

    def _set_mlflow_tracking_uri(self):
        """
        Sets the MLflow tracking URI from environment variable.
        """
        mlflow_tracking_uri = os.getenv("MLFLOW_TRACKING_URI")
        if not mlflow_tracking_uri:
            raise ValueError("MLFLOW_TRACKING_URI environment variable not set.")
        mlflow.set_tracking_uri(mlflow_tracking_uri)
        print(f"MLflow tracking URI set to: {mlflow_tracking_uri}")

    async def sync_models(self, request: SyncModelsRequest):
      registry_models = mlflow.search_registered_models()
      print(f"Remote models: {registry_models}")
      # iterate over models in dictionary
      for model_name, model_version in request.models.items():
          print(f"Requested: {model_name}:{model_version}")
          try:
            latest_versions = await self.mlflow_client.get_latest_versions(model_name, stages=[None])
            print(f"  latest versions: {[v.version for v in latest_versions]}")
          except Exception as e:
            print(f"  no versions found")
      # Fetch models from MLflow Model Registry
      # Check deployed models
      
      # Determine which models to download
      
      # Start async job to download models from MLflow Model Registry
      return "test"